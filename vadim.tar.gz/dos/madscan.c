 /* madscan v 1.0 by ThE MaDj0kEr
    based on broadscan 0.31 by Vacuum http://www.technotronic.com

    it's a scanner which finds DUP broadcast ip addresses.
    it works 4 times faster than original, and also allows
    scanning a full a-class.

    Dedicated to Itze... she knows why

    Thanks to DarkHeavy for hosting and testing ;)
 */

#include <stdlib.h>
#include <stdio.h>

#define DEBUG 1

FILE *stream;

void pingz0r(int first, int second, int start, int end)
{
int counter,flag,cont;
FILE *stream;
char tempstring[2048];
char parse[2048];

if (second==255) {
 for (cont=0; cont<255; cont++)
 {
  for (counter=start; counter <end; counter++)
  {
   flag=0;
   sprintf(tempstring,"ping -c 2 -n  %d.%d.%d.255 2>/dev/null",first,
                       cont, counter);
   stream=popen(tempstring,"r");
   while (fgets(parse,sizeof(parse),stream)!=NULL)
   {
    if (DEBUG) printf("Results:%s",parse);
    if (strstr(parse,"DUP"))
    {
      flag=1;
      fclose(stream);
      break;
    }
   }
   if (flag==1)
   stream=fopen("broadcast.txt", "a");
   fprintf(stream, "%d.%d.%d.255\n",first,cont,counter);
   fclose( stream);
  }
 }
} else

 for (counter=start; counter <end; counter++)
 {
  flag=0;
  sprintf(tempstring,"ping -c 2 -n  %d.%d.%d.255 2>/dev/null",first,
                      second, counter);
  stream=popen(tempstring,"r");
  while (fgets(parse,sizeof(parse),stream)!=NULL)
  {
   if (DEBUG) printf("Results:%s",parse);
   if (strstr(parse,"DUP"))
   {
     flag=1;
     fclose(stream);
     break;
   }
  }
  if (flag==1)
  stream=fopen("broadcast.txt", "a");
  fprintf(stream, "%d.%d.%d.255\n",first,second,counter);
  fclose( stream);
 }
 }


main(int argc, char *argv[])

{
int first,second,count;

if (argc!=3)
 {
  printf("\nusage : %s <octet(A)> <octet(B)>\n\n",argv[0]);
  printf("Setting octec(B) as 255 then madscan will scan a full
A-Class\n\n");
  exit(0);
 }

first=atoi(argv[1]);
second=atoi(argv[2]);

if (first==127)
 {
 printf("%d is a localhost. You have no clue or are trying to break this
progra
m",first);
 exit(0);
 }
if (first>254  || first <0)
 {
 printf("First octet is: %d. It must be between <1-254>",first);
 exit(0);
 }
if (second>255 || second<0)
 {
 printf("Second octet is: %d. It must be <1-254> or 255 for full-class
scan",second);
 exit(0);
 }

printf("Scanning for DUP broadcast ip addresses\n");
printf("Results output to broadcast.txt\n");

if (fork()!=0)
        pingz0r(first,second,0,32);
else
 if (fork()!=0)
         pingz0r(first,second,32,64);
 else
  if (fork()!=0)
   pingz0r(first,second,64,96);
  else
   if (fork()!=0)
    pingz0r(first,second,96,128);
   else
    if(fork()!=0)
     pingz0r(first,second,128,160);
    else
     if (fork()!=0)
      pingz0r(first,second,160,192);
     else
      if (fork()!=0)
       pingz0r(first,second,192,224);
      else
       pingz0r(first,second,224,255);

}




